function drawArcCircle(canvas) {
  var context = canvas.getContext("2d");

  //TODO 1.2)       Use the arc function to
  //                rasterize the two circles
  //                from Task 1.1.



}
