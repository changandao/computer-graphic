precision mediump float;

//////////////////////////////////////////////////////////////
// Exercise 3.3: Circle from Quad
//  define a constant variable (uniform) to define the canvas size from the "outside"

void main(void)
{
	//////////////////////////////////////////////////////////////
	// Exercise 3.3: Circle from Quad
	// map the fragment coordinate gl_FragCoord into the range of [-1,1]
	// discard all elements "outside" the radius length
	// smooth the circle edge within [r-smoothMargin, r] by computing an appropriate alpha value

	 float smoothMargin = .01;
	 float r = 0.8;

	 //vec2 uv = gl_FragCoord.xy ...

	gl_FragColor = vec4(1.0,0,0,1.0);
}